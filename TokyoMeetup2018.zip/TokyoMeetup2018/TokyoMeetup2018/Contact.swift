//
//  Contact.swift
//  TokyoMeetup2018
//
//  Created by Jeffrey Bergier on 03/03/2018.
//  Copyright © 2018 Jeffrey Bergier. All rights reserved.
//

import Foundation

struct Contact {
    var name: String?
}
